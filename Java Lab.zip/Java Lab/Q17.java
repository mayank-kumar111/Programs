class Q17 {
    public static void main(String ttt[]) {
        int p[] = new int[5];
        p[0] = 1;
        p[1] = 11;
        p[2] = 111;
        p[3] = 1111;
        p[4] = 11111;

        float q[] = { 1.1f, 2.2f, 3.3f };
        double r[];
        r = new double[4];

        int c = 6;
        long l[] = new long[c];
        System.out.println(p.length);
        System.out.println(q.length);
        System.out.println(r.length);
        System.out.println(l.length);

        System.out.println(p[3]);
        System.out.println(q[2]);
    }
}
