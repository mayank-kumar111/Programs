import java.util.Scanner;

class Q4 {

    public static void main(String args[]) {
        int a;
        double c;
        String s;
        Scanner sc = new Scanner(System.in);
        s = sc.nextLine();
        System.out.println(s);
        a = sc.nextInt();
        System.out.println(a);
        c = sc.nextDouble();
        System.out.println(c);
        sc.close();
    }
}
